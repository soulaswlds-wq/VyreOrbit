# VyreOrbit: сборка через GitHub

1. Создай на GitHub **приватный** репозиторий и загрузи в него содержимое этой папки
   (`.github/workflows/build.yml`, `patches/vyreorbit.patch`, `SETUP.md`).
2. На https://my.telegram.org -> API development tools получи свои `api_id` и `api_hash`.
3. Ключ подписи (keystore) создаётся один раз. Без ПК это можно сделать прямо в Actions
   или в Termux на телефоне:
   `keytool -genkeypair -v -keystore vyre.jks -alias vyre -keyalg RSA -keysize 2048 -validity 10000`
   Потом `base64 -w0 vyre.jks` даёт строку для секрета KEYSTORE_BASE64.
   Храни keystore: без него обновления не встанут поверх старой версии.
4. В репозитории: Settings -> Secrets and variables -> Actions -> New repository secret:
   APP_ID, APP_HASH, KEYSTORE_BASE64, SIGNING_KEY_STORE_PASSWORD, SIGNING_KEY_ALIAS,
   SIGNING_KEY_PASSWORD, MAPS_V2_API (необязательно: карты не заработают без него).
5. Actions -> Build VyreOrbit -> Run workflow. APK появится в Artifacts внизу страницы запуска.
